Crimstone is a bold and strong geometric typeface. Rectangular shape with rigid and sharp edges is the first impression that makes this font look powerful and hit. Its continued development created other variations including rounded styles, inline and handmade styles.

Not only the clean version, Crimstone is also available in a printed version with a rough and textured appearance. Each has an upright and slanted version.

Available in 16 fonts, Crimstone family is perfect for poster designs, headlines, movie titles, logotypes, packaging etc.


2019 © Locomotype Studio
========================
http://locomotype.com
locomotype@gmail.com